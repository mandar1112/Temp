import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense
import matplotlib.pyplot as plt
import numpy as np

NUM_CLASSES = 10
EPOCHS = 10
BATCH_SIZE = 128

print("--- Starting CNN Image Classification ---")

print("\n[Stage A] Loading and preprocessing image data...")

(x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data()

x_train = x_train.reshape(x_train.shape[0], 28, 28, 1)
x_test = x_test.reshape(x_test.shape[0], 28, 28, 1)
input_shape = (28, 28, 1)

x_train = x_train.astype("float32") / 255.0
x_test = x_test.astype("float32") / 255.0

print(f"Input shape: {input_shape}")


print("\n[Stage B] Defining the model's architecture (CNN)...")
model = Sequential([

    Conv2D(32, kernel_size=(3, 3), activation='relu', input_shape=input_shape),
    MaxPooling2D(pool_size=(2, 2)),

    Conv2D(64, kernel_size=(3, 3), activation='relu'),
    MaxPooling2D(pool_size=(2, 2)),

    Flatten(), 
    Dense(128, activation='relu'),
    Dense(NUM_CLASSES, activation='softmax') # Output layer
])

model.summary()


print("\n[Stage C] Compiling and training the model...")

model.compile(
    optimizer='adam',
    loss='sparse_categorical_crossentropy', 
    metrics=['accuracy']
)

H = model.fit(
    x_train, y_train,
    validation_data=(x_test, y_test),
    epochs=EPOCHS,
    batch_size=BATCH_SIZE,
    verbose=1
)
print("Model training complete.")


print("\n[Stage D] Estimating the model's performance...")

test_loss, test_accuracy = model.evaluate(x_test, y_test, verbose=0)
print(f"Final Test Loss: {test_loss:.4f}")
print(f"Final Test Accuracy: {test_accuracy*100:.2f}%")

plt.style.use("ggplot")
plt.figure(figsize=(12, 5))

plt.subplot(1, 2, 1)
plt.plot(np.arange(0, EPOCHS), H.history["loss"], label="Train Loss")
plt.plot(np.arange(0, EPOCHS), H.history["val_loss"], label="Validation Loss")
plt.title("Training and Validation Loss")
plt.xlabel("Epoch #")
plt.ylabel("Loss")
plt.legend()

plt.subplot(1, 2, 2)
plt.plot(np.arange(0, EPOCHS), H.history["accuracy"], label="Train Accuracy")
plt.plot(np.arange(0, EPOCHS), H.history["val_accuracy"], label="Validation Accuracy")
plt.title("Training and Validation Accuracy")
plt.xlabel("Epoch #")
plt.ylabel("Accuracy")
plt.legend()

plt.tight_layout()
plt.show()

random_index = np.random.randint(0, len(x_test))
sample_image = x_test[random_index]
true_label = y_test[random_index]

sample_image_batch = np.expand_dims(sample_image, axis=0)
prediction = model.predict(sample_image_batch, verbose=0)
predicted_label = np.argmax(prediction[0])

print(f"\nExample Prediction on Test Image:")
print(f"True Label: {true_label}")
print(f"Predicted Label: {predicted_label}")