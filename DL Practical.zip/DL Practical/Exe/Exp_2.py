import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Flatten
from tensorflow.keras.optimizers import SGD
from tensorflow.keras.datasets import mnist
import matplotlib.pyplot as plt
import numpy as np

NUM_CLASSES = 10
INPUT_SHAPE = (28, 28)
BATCH_SIZE = 128
EPOCHS = 10
LEARNING_RATE = 0.01

print("[INFO] Loading and preprocessing data...")
(x_train, y_train), (x_test, y_test) = mnist.load_data()

x_train = x_train.astype("float32") / 255.0
x_test = x_test.astype("float32") / 255.0


print("[INFO] Defining network architecture...")
model = Sequential([

    Flatten(input_shape=INPUT_SHAPE),
    Dense(256, activation='relu'),
    Dense(128, activation='relu'),
    Dense(NUM_CLASSES, activation='softmax')
])

model.summary()

print("[INFO] Compiling model with SGD optimizer...")
sgd_optimizer = SGD(learning_rate=LEARNING_RATE)
model.compile(
    optimizer=sgd_optimizer,
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy']
)

print("[INFO] Training network...")
H = model.fit(
    x_train, y_train,
    validation_data=(x_test, y_test),
    epochs=EPOCHS,
    batch_size=BATCH_SIZE,
    verbose=1
)

print("[INFO] Evaluating network...")
loss, accuracy = model.evaluate(x_test, y_test, verbose=0)
print(f"Test Loss: {loss:.4f}")
print(f"Test Accuracy: {accuracy*100:.2f}%")

print("[INFO] Plotting training loss and accuracy...")
plt.style.use("ggplot")
plt.figure(figsize=(12, 4))

plt.subplot(1, 2, 1)
plt.plot(np.arange(0, EPOCHS), H.history["loss"], label="train_loss")
plt.plot(np.arange(0, EPOCHS), H.history["val_loss"], label="val_loss")
plt.title("Training Loss and Validation Loss")
plt.xlabel("Epoch #")
plt.ylabel("Loss")
plt.legend()

plt.subplot(1, 2, 2)
plt.plot(np.arange(0, EPOCHS), H.history["accuracy"], label="train_acc")
plt.plot(np.arange(0, EPOCHS), H.history["val_accuracy"], label="val_acc")
plt.title("Training Accuracy and Validation Accuracy")
plt.xlabel("Epoch #")
plt.ylabel("Accuracy")
plt.legend()

plt.tight_layout()
plt.show()

# Example Prediction
# Get a random image from the test set
random_index = np.random.randint(0, len(x_test))
sample_image = x_test[random_index]
true_label = y_test[random_index]

# Keras expects a batch of inputs, so we add a dimension
sample_image_batch = np.expand_dims(sample_image, axis=0)
prediction = model.predict(sample_image_batch)
predicted_label = np.argmax(prediction[0])

print(f"\nExample Prediction:")
print(f"True Label: {true_label}")
print(f"Predicted Label: {predicted_label}")
print(f"Confidence: {prediction[0][predicted_label]*100:.2f}%")

plt.imshow(sample_image, cmap='gray')
plt.title(f"True: {true_label}, Predicted: {predicted_label}")
plt.axis('off')
plt.show()