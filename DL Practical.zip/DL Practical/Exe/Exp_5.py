import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, Embedding, Lambda, Reshape
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.utils import to_categorical
from tensorflow.keras import backend as K

CONTEXT_WINDOW_SIZE = 2  
EMBEDDING_DIM = 50       
HIDDEN_DIM = 128
BATCH_SIZE = 32        
EPOCHS = 100
LEARNING_RATE = 0.001

def create_lookup_tables(text_data):
    """Tokenizes text and creates word-to-index and index-to-word mappings."""
    
    tokens = [word.lower() for sentence in text_data for word in sentence.split()]
    

    vocab = sorted(list(set(tokens)))
    word_to_idx = {word: i for i, word in enumerate(vocab)}
    idx_to_word = {i: word for i, word in enumerate(vocab)}
    
    vocab_size = len(vocab)
    
    return tokens, vocab_size, word_to_idx, idx_to_word


text_data = [
    "The quick brown fox jumps over the lazy dog",
    "Word embeddings are useful for natural language processing",
    "CBOW predicts the word from context"
]

print("--- Starting CBOW Implementation ---")
print("\n[Stage A] Data Preparation...")

tokens, VOCAB_SIZE, word_to_idx, idx_to_word = create_lookup_tables(text_data)
print(f"Vocabulary Size: {VOCAB_SIZE}")
print(f"Total Tokens: {len(tokens)}")

print("\n[Stage B] Generating training data (Context-Target pairs)...")

X_context = []
Y_target = []  

for i, target_word in enumerate(tokens):
    start_index = max(0, i - CONTEXT_WINDOW_SIZE)
    end_index = min(len(tokens), i + CONTEXT_WINDOW_SIZE + 1)
    
    context_words = tokens[start_index:i] + tokens[i+1:end_index]
    
    if not context_words:
        continue

    
    context_indices = [word_to_idx[w] for w in context_words]
    
    X_context.append(context_indices)
    
    target_index = word_to_idx[target_word]
    Y_target.append(target_index)

MAX_CONTEXT_LEN = 2 * CONTEXT_WINDOW_SIZE 
X_context = tf.keras.preprocessing.sequence.pad_sequences(
    X_context, maxlen=MAX_CONTEXT_LEN, padding='post', value=VOCAB_SIZE
)
Y_target = np.array(Y_target)

Y_target_one_hot = to_categorical(Y_target, num_classes=VOCAB_SIZE)

print(f"Shape of X_context (Input): {X_context.shape}")
print(f"Shape of Y_target (Output): {Y_target_one_hot.shape}")
print(f"Max Context Length (Input Size): {MAX_CONTEXT_LEN}")


print("\n[Stage C - Part 1] Defining Model Architecture...")

input_context = Input(shape=(MAX_CONTEXT_LEN,), name='context_input')

embedding_layer = Embedding(
    input_dim=VOCAB_SIZE + 1, 
    output_dim=EMBEDDING_DIM,
    mask_zero=True,
    name='word_embedding'
)(input_context)

summed_embeddings = Lambda(lambda x: K.sum(x, axis=1), output_shape=(EMBEDDING_DIM,))(embedding_layer)

projection = Dense(HIDDEN_DIM, activation='relu', name='projection_layer')(summed_embeddings)

output_word = Dense(VOCAB_SIZE, activation='softmax', name='output_softmax')(projection)

cbow_model = Model(inputs=input_context, outputs=output_word, name='CBOW_Model')
cbow_model.summary()

print("\n[Stage C - Part 2] Training Model...")

cbow_model.compile(
    optimizer=Adam(learning_rate=LEARNING_RATE),
    loss='categorical_crossentropy',
    metrics=['accuracy']
)

history = cbow_model.fit(
    X_context, 
    Y_target_one_hot,
    epochs=EPOCHS,
    batch_size=BATCH_SIZE,
    verbose=0 
)
print(f"Training finished after {EPOCHS} epochs.")


print("\n[Stage D] Outputting Word Embeddings and Sample Prediction...")

word_vectors = cbow_model.get_layer('word_embedding').get_weights()[0]

print(f"\nExtracted Word Vector Shape: {word_vectors.shape}")
print(f"First 5 dimensions of 'fox': {word_vectors[word_to_idx['fox']][:5]}")
print(f"First 5 dimensions of 'dog': {word_vectors[word_to_idx['dog']][:5]}")


sample_context_words = ["the", "quick", "jumps", "over"]
sample_indices = [word_to_idx.get(w, 0) for w in sample_context_words]
input_data = tf.keras.preprocessing.sequence.pad_sequences(
    [sample_indices], maxlen=MAX_CONTEXT_LEN, padding='post', value=VOCAB_SIZE
)

prediction_probabilities = cbow_model.predict(input_data, verbose=0)[0]
predicted_index = np.argmax(prediction_probabilities)
predicted_word = idx_to_word[predicted_index]

print(f"\nContext: {sample_context_words}")
print(f"Predicted Word (Highest Probability): {predicted_word}")