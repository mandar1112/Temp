import tensorflow as tf
from tensorflow.keras.applications import VGG16
from tensorflow.keras.applications.vgg16 import preprocess_input
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense, Flatten, Dropout, Input
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.utils import to_categorical
import numpy as np

IMG_SIZE = 32 
INPUT_SHAPE = (IMG_SIZE, IMG_SIZE, 3)
NUM_CLASSES = 10

BATCH_SIZE = 128  
EPOCHS_CLASSIFIER = 1 
EPOCHS_FINETUNE = 1 

print("\n--- Starting Transfer Learning Implementation (VGG16) ---")

print("\n[Stage A] Generating local image matrix arrays to bypass network download...")
x_train = np.random.randint(0, 256, size=(1000, 32, 32, 3), dtype=np.uint8)
y_train = np.random.randint(0, NUM_CLASSES, size=(1000, 1))

x_test = np.random.randint(0, 256, size=(200, 32, 32, 3), dtype=np.uint8)
y_test = np.random.randint(0, NUM_CLASSES, size=(200, 1))

x_train = preprocess_input(x_train.astype('float32'))
x_test = preprocess_input(x_test.astype('float32'))
y_train = to_categorical(y_train, NUM_CLASSES)
y_test = to_categorical(y_test, NUM_CLASSES)

print("\n[Stage B] Loading VGG16 (ImageNet weights) without top layers...")
base_model = VGG16(
    weights='imagenet',
    include_top=False,
    input_shape=INPUT_SHAPE 
)
base_model.trainable = False 

print("[Stage C] Adding custom trainable classifier head...")
inputs = Input(shape=INPUT_SHAPE)
x = base_model(inputs, training=False)
x = Flatten()(x)
x = Dense(256, activation='relu')(x) 
x = Dropout(0.5)(x)
outputs = Dense(NUM_CLASSES, activation='softmax')(x)

model = Model(inputs, outputs)

model.compile(
    optimizer=Adam(learning_rate=0.001),
    loss='categorical_crossentropy',
    metrics=['accuracy']
)

print(f"\n[Stage D] Training classifier head layers...")
model.fit(
    x_train, y_train,
    epochs=EPOCHS_CLASSIFIER,
    batch_size=BATCH_SIZE,
    validation_data=(x_test, y_test)
)

print(f"\n[Stage E] Fine-tuning: Unfreezing high-level feature blocks...")
base_model.trainable = True

for layer in base_model.layers:
    if any(layer.name.startswith(block) for block in ['block1', 'block2', 'block3']):
        layer.trainable = False

model.compile(
    optimizer=Adam(learning_rate=0.00001),
    loss='categorical_crossentropy',
    metrics=['accuracy']
)

print(f"\nFine-tuning entire structural model graph...")
model.fit(
    x_train, y_train,
    epochs=EPOCHS_FINETUNE,
    batch_size=BATCH_SIZE,
    validation_data=(x_test, y_test)
)

print("\n--- Final Model Performance Estimation ---")
loss, accuracy = model.evaluate(x_test, y_test, verbose=0)
print(f"Test Loss after Fine-tuning: {loss:.4f}")
print(f"Test Accuracy after Fine-tuning: {accuracy*100:.2f}%")
